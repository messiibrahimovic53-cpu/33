package kgz.mobile.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(8,13,18), PANEL = Color.rgb(17,26,35), LIME = Color.rgb(184,255,59);
    private LinearLayout root, content;
    private TextView status;
    private static final String IP = "188.127.241.74:1926";
    private static final String NEWS_URL = "https://example.com/kgz-news.json";
    private static final String RULES_URL = "https://example.com/kgz-rules.txt";
    private static final String FILES_URL = "https://example.com/kgz-files/";

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        buildUI();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setPadding(0, 5, 0, 5); return t;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(14);
        b.setTextColor(label.contains("ПОДКЛЮЧИТЬСЯ") ? Color.rgb(12,20,8) : Color.WHITE);
        b.setBackground(shape(label.contains("ПОДКЛЮЧИТЬСЯ") ? LIME : Color.rgb(35,49,60), 24));
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = 10; b.setLayoutParams(lp);
        return b;
    }
    private void buildUI() {
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(BG);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(22, 28, 22, 24);
        scroll.addView(root); setContentView(scroll);
        root.addView(text("KGZ  MOBILE   •   GTA SAMP", 15, LIME, true));
        root.addView(text("ТВОЯ ИГРА.\nТВОЙ ГОРОД.", 34, Color.WHITE, true));
        root.addView(text("Мобильный лаунчер проекта KGZ Mobile", 15, Color.LTGRAY, false));
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(18,18,18,18); card.setBackground(shape(PANEL, 28));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.topMargin=22; root.addView(card,cp);
        card.addView(text("KGZ MOBILE", 21, Color.WHITE, true));
        card.addView(text(IP, 16, LIME, true));
        status = text("Статус: не проверен (нет настроенного API статуса)", 12, Color.LTGRAY, false); card.addView(status);
        card.addView(button("▶  ПОДКЛЮЧИТЬСЯ", this::connect));
        card.addView(button("СКОПИРОВАТЬ IP", this::copyIp));
        root.addView(text("РАЗДЕЛЫ", 12, LIME, true));
        root.addView(button("НОВОСТИ ПРОЕКТА", () -> showInfo("Новости", "Новости пока не настроены. Добавьте свой URL в NEWS_URL в MainActivity.java.")));
        root.addView(button("ПРАВИЛА СЕРВЕРА", () -> showInfo("Правила сервера", "Правила пока не настроены. Добавьте официальный текст правил в RULES_URL или замените этот текст в MainActivity.java.")));
        root.addView(button("ОНЛАЙН ИГРОКОВ", this::showOnline));
        root.addView(button("СКАЧАТЬ ИГРОВЫЕ ФАЙЛЫ", this::downloadFiles));
        root.addView(text("Важно: кнопка подключения открывает samp:// ссылку. Нужен установленный совместимый SAMP-клиент Android. Онлайн не может достоверно показываться без работающего query/API сервера.", 12, Color.GRAY, false));
        root.addView(text("KGZ MOBILE • ФАН-ПРОЕКТ", 11, Color.GRAY, true));
    }
    private void connect() {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("samp://" + IP))); }
        catch (Exception e) { showInfo("Клиент не найден", "Установи совместимый SAMP-клиент для Android. Затем скопируй IP " + IP + " и добавь сервер вручную."); }
    }
    private void copyIp() {
        ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("KGZ Mobile server", IP));
        Toast.makeText(this, "IP скопирован: " + IP, Toast.LENGTH_LONG).show();
    }
    private void showInfo(String title, String message) {
        new android.app.AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show();
    }
    private void showOnline() {
        showInfo("Онлайн игроков", "Онлайн пока не подключён: для реальных данных нужен доступный серверный API или SA-MP query endpoint. Не показываем выдуманные цифры.");
    }
    private void downloadFiles() {
        new android.app.AlertDialog.Builder(this).setTitle("Игровые файлы")
          .setMessage("Укажи официальный HTTPS-адрес архива/файлов проекта в FILES_URL в MainActivity.java. Сейчас ссылка-заглушка, загрузка не выполняется.")
          .setNegativeButton("Отмена", null)
          .setPositiveButton("Открыть ссылку", (d,w) -> {
              try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(FILES_URL))); }
              catch (Exception e) { Toast.makeText(this, "Ссылка не настроена", Toast.LENGTH_SHORT).show(); }
          }).show();
    }
}
